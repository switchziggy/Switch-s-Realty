/* =========================================
   SWITCH REALTY
   JavaScript
========================================= */


/* =========================================
   MOBILE MENU
========================================= */

function toggleMenu() {

    const menu = document.getElementById("mobileMenu");

    if (menu.style.display === "block") {
        menu.style.display = "none";
    } else {
        menu.style.display = "block";
    }
}


function closeMenu() {

    const menu = document.getElementById("mobileMenu");

    menu.style.display = "none";
}


/* =========================================
   MESSAGE POPUP
========================================= */

function showMessage(message) {

    const messageBox = document.getElementById("messageBox");
    const messageText = document.getElementById("messageText");

    messageText.innerHTML = message;

    messageBox.style.display = "flex";
}


function closeMessage() {

    const messageBox = document.getElementById("messageBox");

    messageBox.style.display = "none";
}


/* =========================================
   PROPERTY SEARCH
========================================= */

function searchProperties() {

    const type = document.getElementById("propertyType").value;
    const location = document.getElementById("location").value;
    const purpose = document.getElementById("purpose").value;

    const properties =
        document.querySelectorAll(".property-card");

    let found = 0;


    properties.forEach(function(property) {

        const propertyType =
            property.getAttribute("data-type");

        const propertyLocation =
            property.getAttribute("data-location");

        const propertyPurpose =
            property.getAttribute("data-purpose");


        const typeMatch =
            type === "all" ||
            type === propertyType;

        const locationMatch =
            location === "all" ||
            location === propertyLocation;

        const purposeMatch =
            purpose === "all" ||
            purpose === propertyPurpose;


        if (
            typeMatch &&
            locationMatch &&
            purposeMatch
        ) {

            property.style.display = "block";

            found++;

        } else {

            property.style.display = "none";

        }

    });


    document
        .getElementById("properties")
        .scrollIntoView({
            behavior: "smooth"
        });


    if (found === 0) {

        showMessage(
            "No properties match your search yet.<br><br>" +
            "More properties will be added to Switch Realty soon."
        );

    }

}


/* =========================================
   CATEGORY SEARCH
========================================= */

function selectCategory(category) {

    const propertyType =
        document.getElementById("propertyType");

    propertyType.value = category;

    searchProperties();

}


/* =========================================
   FAVORITE PROPERTY
========================================= */

function favoriteProperty(button) {

    if (button.classList.contains("active")) {

        button.classList.remove("active");

        button.innerHTML = "♡";

        showMessage(
            "Property removed from your favourites."
        );

    } else {

        button.classList.add("active");

        button.innerHTML = "♥";

        showMessage(
            "Property added to your favourites!"
        );

    }

}


/* =========================================
   VIEW PROPERTY
========================================= */

function viewProperty(propertyName) {

    showMessage(

        "<h3>" +
        propertyName +
        "</h3>" +

        "<br>" +

        "<p>" +
        "The full property page will be available " +
        "in the next version of Switch Realty." +
        "</p>"

    );

}


/* =========================================
   CLOSE POPUP WHEN CLICKING OUTSIDE
========================================= */

window.addEventListener("click", function(event) {

    const messageBox =
        document.getElementById("messageBox");

    if (event.target === messageBox) {

        closeMessage();

    }

});


/* =========================================
   STARTUP MESSAGE
========================================= */

console.log(
    "Switch Realty loaded successfully."
);
/* =========================================
   LOAD USER-LISTED PROPERTIES
========================================= */

function loadUserProperties() {

    const listings =
        JSON.parse(localStorage.getItem("switchRealtyListings")) || [];

    const propertyGrid =
        document.getElementById("propertyGrid");

    if (!propertyGrid) return;


    listings.forEach(function(property) {

        const card = document.createElement("article");

        card.className = "property-card";

        card.setAttribute(
            "data-type",
            property.propertyType
        );

        card.setAttribute(
            "data-location",
            property.location
        );

        card.setAttribute(
            "data-purpose",
            property.purpose
        );


        card.innerHTML = `

            <div class="property-image">

                <div class="property-placeholder">
                    🏠
                </div>

                <span class="property-status">
                    ${property.purpose.toUpperCase()}
                </span>

                <button
                    class="favorite-button"
                    onclick="favoriteProperty(this)">
                    ♡
                </button>

            </div>


            <div class="property-info">

                <p class="property-location">
                    📍 ${property.location}, Plateau State
                </p>

                <h3>
                    ${property.title}
                </h3>

                <p class="property-details">
                    🛏 ${property.bedrooms || "N/A"} Bedrooms
                    &nbsp; • &nbsp;
                    🚿 ${property.bathrooms || "N/A"} Bathrooms
                </p>

                <div class="property-bottom">

                    <strong>
                        ₦${property.price}
                    </strong>

                    <button
                        onclick="viewProperty('${property.title}')">
                        View
                    </button>

                </div>

            </div>
        `;


        propertyGrid.appendChild(card);

    });

}


/* =========================================
   LOAD PROPERTIES WHEN PAGE OPENS
========================================= */

window.addEventListener("DOMContentLoaded", function() {

    loadUserProperties();

});